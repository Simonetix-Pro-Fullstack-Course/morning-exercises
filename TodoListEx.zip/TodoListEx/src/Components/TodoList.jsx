import React, { useState } from "react";
import MainTodo from "./MainTodo";
import TodoForm from "./TodoForm";

export default function TodoList() {
  const [todos, setTodo] = useState([]);

  // addTodo function - regex //
  const addTodo = (todo) => {
    console.log(todo);
    if (!todo.text || /^\s*$/.test(todo.text)) {
      return;
    }
    let newTodos = [todo, ...todos];
    console.log(newTodos);
    setTodo(newTodos);
    console.log(...todos);
  };

  // updateTodo() - updates the items inside the todo list //
  const updateTodo = (todoId, todoValue) => {
    if (!todoValue.text || /^\s*$/.test(todoValue.text)) {
      return;
    }

    setTodo((previous) => {
      previous.map((item) => {
        return item.id === todoId ? todoValue : item;
      });
    });
  };

  // delete the todo with id //
  const removeTodo = (id) => {
    // filter //
    const removeArr = [...todos].filter((todo) => todo.id !== id);
    setTodo(removeArr);
  };



  return (

    <div>
        <h3>TODO</h3>
        <TodoForm onSubmit={addTodo} />
        <MainTodo 
        todos={todos}
        removeTodo={removeTodo}
        updateTodo={updateTodo}
        />
    </div>

    );
}
