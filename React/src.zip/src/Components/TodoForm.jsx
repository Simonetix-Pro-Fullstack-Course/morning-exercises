import React, { useState, useEffect, useRef } from "react";

export default function TodoForm(props) {
  // useState //
  const [input, setInput] = useState("");

  // useRef //
  const inputRef = useRef();

  // useEffect //

  useEffect(() => {
    inputRef.current.focus(); // DOM
  });

  const handleChange = ({ target: { value } }) => {
      setInput(value);
  };

  const handleSubmit = (e) =>{
      e.preventDefault();
      
      // each time I submit the form - it suppose to store the input (variable) inside text (property) 
      // and generate a random Id in order to get unique referencing /// 
      props.onSubmit({
          text:input,
          id:Math.floor(Math.random() * 1000)
      })
      // reset after submitting  //
      setInput('');
  }

  return(
      <div>
          <form className="todo-form" onSubmit={handleSubmit}>
              <input 
              name="text"
              placeholder="Add something!"
              className="todo-input"
              onChange={handleChange}
              value={input}
              ref={inputRef}
              />

            <button className="todo-btn">Add</button>

          </form>
      </div>
  )
}
