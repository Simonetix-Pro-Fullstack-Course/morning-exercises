import React, { useState } from "react";
// import { RiCloseCircleLine} from "react-icons/ri";
import TodoForm from "./TodoForm";

export default function MainTodo({
  todos,
  completeTodo,
  removeTodo,
  updateTodo,
}) {
  console.log(todos);
  const [edit, setEdit] = useState({
    value: "",
    id: null,
  });

  const submitUpdate = (value) => {
    updateTodo(edit.id, value);
    setEdit({
      value: "",
      id: null,
    });
    if (edit.id) {
      //if it's true or if have an id value //
      return <TodoForm edit={edit} onSubmit={submitUpdate} />;
    }

    return todos.map((todo, index) => {
      <div>
        <div
          className={todo.isCompeleted ? "todo-row complete" : "todo-row"}
          key={index}
        />
        <div key={todo.id}>{todo.text}</div>
        <div className="icon-container">
          <div className="delete-icon" onClick={removeTodo(todo.id)}>X</div>
          <div className="edit-icon" onClick={setEdit({id:todo.id, value:todo.text})}>!Edit!</div>
        </div>
      </div>;
    });
  };

  return <div>MainTodo</div>;
}
